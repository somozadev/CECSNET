﻿#include <SFML/Graphics.hpp>
#include <iostream>
#include "ecs.h"
#include "ecs_builtin.h"
#include "ecs_internal.h"
#include "network_cs.h"

#ifdef _WIN32
#include <winsock2.h>
#endif

#define INPUT_UP 0x01
#define INPUT_DOWN 0x02
#define INPUT_SPAWN  0x80

static const char* g_server_peer_id = nullptr;


// Tamaño de las “gotas”
static constexpr float DROP_WIDTH  = 3.f;
static constexpr float DROP_HEIGHT = 14.f;

ecs_t client_ecs;


void print_entity_table(ecs_t *ecs) {
    printf("\033[2J\033[H");
    printf("| Entity ID | Component ID | Data Preview |\n");
    printf("|-----------|--------------|--------------|\n");
    for (int entity = 0; entity < ecs->registered_entities_count; ++entity) {
        for (int comp_id = 0; comp_id < ecs->registered_component_count; ++comp_id) {
            if (ecs_has_component(ecs, entity, comp_id)) {
                void *comp_data = ecs_get_component(ecs, entity, comp_id);
                printf("| %9d | %12d | %12p |\n", entity, comp_id, comp_data);
            }
        }
    }
}
void on_client_receive_callback(void *user_data, peer_t *peer, const void *data, int len) {
    ecs_t* ecs = (ecs_t*)user_data;

    // 1) Cachear peer id (puntero tal cual)
    if (!g_server_peer_id && peer && peer->id) {
        g_server_peer_id = peer->id;
        printf("[Client] Server peer id cached: %s\n", g_server_peer_id);
    }

    // 2) Validaciones básicas de paquete
    if (!data || len < (int)sizeof(packet_header_t)) {
        // paquete vacío o demasiado corto; ignorar
        return;
    }

    const network_packet_t* packet = (const network_packet_t*)data;

    // 3) Soportar ambos tipos de update
    switch (packet->header.type) {
    case PACKET_TYPE_MULTI_ENTITY_UPDATE: {
        const uint8_t* current = packet->data;
        const uint8_t* end = ((const uint8_t*)packet) + packet->header.size;

        // Leer número de entidades
        if (end - current < (ptrdiff_t)sizeof(uint16_t)) return;
        uint16_t entity_count;
        memcpy(&entity_count, current, sizeof(uint16_t));
        current += sizeof(uint16_t);

        for (uint16_t eidx = 0; eidx < entity_count; ++eidx) {
            // entity_id
            if (end - current < (ptrdiff_t)sizeof(entity_t)) break;
            entity_t entity_id;
            memcpy(&entity_id, current, sizeof(entity_id));
            current += sizeof(entity_id);

            ecs_try_create_entity_by_id(ecs, entity_id);

            // comp_count
            if (end - current < (ptrdiff_t)sizeof(uint8_t)) break;
            uint8_t comp_count;
            memcpy(&comp_count, current, sizeof(uint8_t));
            current += sizeof(uint8_t);

            for (uint8_t c = 0; c < comp_count; ++c) {
                if (end - current < (ptrdiff_t)sizeof(component_t)) break;
                component_t comp_id;
                memcpy(&comp_id, current, sizeof(component_t));
                current += sizeof(component_t);

                // 4) Blindaje comp_id
                if (comp_id < 0 || comp_id >= ecs->registered_component_count) {
                    printf("[Client] Skipping invalid component id %d\n", (int)comp_id);
                    return;
                }

                size_t comp_size = ecs->components[comp_id].descriptor.size;
                if (end - current < (ptrdiff_t)comp_size) break;

                ecs_add_component(ecs, entity_id, comp_id, (void*)current);
                current += comp_size;
            }
        }
        break;
    }

    case PACKET_TYPE_ENTITY_UPDATE: { // <-- el que envía tu server
        const uint8_t* p   = packet->data;
        const uint8_t* end = ((const uint8_t*)packet) + packet->header.size;

        // entity_id
        if (end - p < (ptrdiff_t)sizeof(entity_t)) return;
        entity_t wire_eid;
        memcpy(&wire_eid, p, sizeof(entity_t));
        p += sizeof(entity_t);

        ecs_try_create_entity_by_id(ecs, wire_eid);

        // stream de [comp_id][blob] hasta fin
        while (p < end) {
            if (end - p < (ptrdiff_t)sizeof(component_t)) break;
            component_t cid;
            memcpy(&cid, p, sizeof(component_t));
            p += sizeof(component_t);

            if (cid < 0 || cid >= ecs->registered_component_count) {
                printf("[Client] Skipping invalid component id %d\n", (int)cid);
                return;
            }

            size_t comp_size = ecs->components[cid].descriptor.size;
            if (end - p < (ptrdiff_t)comp_size) break;

            ecs_add_component(ecs, wire_eid, cid, (void*)p);
            p += comp_size;
        }
        break;
    }

    default:
        // Ignorar otros tipos
        break;
    }
    print_entity_table(&client_ecs);
}


int main() {
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif

    ecs_init(&client_ecs);

    network_architecture_config_t client_config = {
        .type = ARCH_CLIENT_SERVER,
        .ip_address = "127.0.0.1",
        .is_server = false,
        .tcp_port = 51660,
        .udp_port = 51660,
        .on_packet_received = on_client_receive_callback,
        .user_data = &client_ecs
    };
    network_architecture_t *client_arch = nullptr;
    network_architecture_init(&client_arch, &client_config, &client_ecs);

    sf::RenderWindow window(sf::VideoMode(800, 600), "Pong ECSNET Client");
    window.setVerticalSyncEnabled(true);

    // Un shape reutilizable para todas las gotas
    sf::RectangleShape dropShape(sf::Vector2f(DROP_WIDTH, DROP_HEIGHT));
    dropShape.setFillColor(sf::Color(0, 220, 255)); // cian
    // Si prefieres que la posición sea el centro, descomenta:
    // dropShape.setOrigin(DROP_WIDTH * 0.5f, DROP_HEIGHT * 0.5f);

    sf::Clock clock;

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();

        // Eventos de ventana
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            else if (event.type == sf::Event::MouseButtonPressed &&
                     event.mouseButton.button == sf::Mouse::Left)
            {
                if (!g_server_peer_id) {
                    printf("[Client] No server peer id yet; cannot send SPAWN.\n");
                } else {
                    // coords en el mundo (por si cambias la view)
                    sf::Vector2i pixel(event.mouseButton.x, event.mouseButton.y);
                    sf::Vector2f world = window.mapPixelToCoords(pixel);

                    struct SpawnXY { float x; float y; } xy { world.x, world.y };

                    protocol_handler_t h;
                    protocol_handler_init(&h);
                    protocol_handler_pack_client_input(&h, /*entity_id*/ 0, INPUT_SPAWN, &xy, sizeof(xy));

                    auto* cs = reinterpret_cast<network_cs_t*>(client_arch);

                    protocol_handler_send_packet(&cs->connection_manager, g_server_peer_id, &h);
                    printf("[Client] Sent SPAWN at (%.1f, %.1f)\n", xy.x, xy.y);
                }
            }
        }
        // Red
        network_architecture_update(client_arch, dt);

        // Render
        window.clear(sf::Color::Black);

        // DIBUJAR TODAS LAS ENTIDADES CON POSITION
        for (entity_t e = 0; e < client_ecs.registered_entities_count; ++e) {
            if (!ecs_has_component(&client_ecs, e, COMPONENT_POSITION))
                continue;

            auto* pos = (position_t*)ecs_get_component(&client_ecs, e, COMPONENT_POSITION);
            if (!pos) continue;

            dropShape.setPosition(pos->x, pos->y);
            window.draw(dropShape);
        }

        window.display();

        sf::sleep(sf::milliseconds(16));
    }

    network_architecture_destroy(client_arch);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
